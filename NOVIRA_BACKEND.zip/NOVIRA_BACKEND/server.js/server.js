// ============================================================
// NIVORA ONE - AI BACKEND SERVER
// ============================================================

const express = require("express");
const path = require("path");

const app = express();

const PORT = process.env.PORT || 3000;

// ------------------------------------------------------------
// BASIC SETTINGS
// ------------------------------------------------------------

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true }));

// ------------------------------------------------------------
// SERVE NIVORA ONE FRONTEND
// ------------------------------------------------------------

app.use(express.static(path.join(__dirname)));

// ------------------------------------------------------------
// HEALTH CHECK
// ------------------------------------------------------------

app.get("/api/health", (req, res) => {
    res.json({
        ok: true,
        service: "NIVORA ONE",
        ai: "ready",
        time: new Date().toISOString()
    });
});

// ------------------------------------------------------------
// NIVORA AI
// ------------------------------------------------------------

app.post("/api/ai/chat", async (req, res) => {

    try {

        const {
            prompt,
            context = {},
            history = [],
            app: appInfo = {}
        } = req.body || {};

        // ----------------------------------------------------
        // CHECK USER MESSAGE
        // ----------------------------------------------------

        if (!prompt || typeof prompt !== "string") {

            return res.status(400).json({
                error: "আপনার প্রশ্ন পাওয়া যায়নি।"
            });

        }

        // ----------------------------------------------------
        // GEMINI API KEY
        // ----------------------------------------------------

        const apiKey = process.env.GEMINI_API_KEY;

        if (!apiKey) {

            return res.status(500).json({
                error:
                    "GEMINI_API_KEY server environment-এ সেট করা হয়নি।"
            });

        }

        // ----------------------------------------------------
        // MODEL
        // ----------------------------------------------------

        const model =
            process.env.GEMINI_MODEL ||
            "gemini-2.5-flash";

        // ----------------------------------------------------
        // APP CONTEXT
        // ----------------------------------------------------

        const safeContext = {
            shopProducts: Array.isArray(context.shopProducts)
                ? context.shopProducts
                : [],

            orders: Array.isArray(context.orders)
                ? context.orders
                : [],

            customers: Array.isArray(context.customers)
                ? context.customers
                : [],

            taskEarnTasks: Array.isArray(context.taskEarnTasks)
                ? context.taskEarnTasks
                : [],

            homeo: Array.isArray(context.homeo)
                ? context.homeo
                : [],

            income: Array.isArray(context.income)
                ? context.income
                : [],

            expenses: Array.isArray(context.expenses)
                ? context.expenses
                : [],

            purchases: Array.isArray(context.purchases)
                ? context.purchases
                : [],

            sales: Array.isArray(context.sales)
                ? context.sales
                : [],

            baki: Array.isArray(context.baki)
                ? context.baki
                : [],

            cart: Array.isArray(context.cart)
                ? context.cart
                : []
        };

        // ----------------------------------------------------
        // HISTORY
        // ----------------------------------------------------

        const safeHistory = Array.isArray(history)
            ? history.slice(-20)
            : [];

        // ----------------------------------------------------
        // SYSTEM INSTRUCTION
        // ----------------------------------------------------

        const systemInstruction = `
You are NIVORA AI, the professional AI assistant inside NIVORA ONE.

Your job is to provide useful, accurate and clear answers.

IMPORTANT LANGUAGE RULES:

1. If the user asks in Bengali, answer in Bengali.
2. If the user asks in English, answer in English.
3. If the user mixes Bengali and English, understand the meaning and answer naturally.
4. Do not unnecessarily repeat the user's question.
5. Give practical answers.
6. For calculations, carefully calculate before answering.
7. For business questions, use the business data supplied in the application context.
8. Never invent business records that are not present in the supplied data.
9. If required information is missing, clearly say what information is missing.
10. For medical/homeopathic topics, provide general informational guidance and encourage consultation with a qualified healthcare professional for diagnosis or treatment.
11. Do not claim that you performed an action if you only provided instructions.
12. Maintain professional and respectful language.

NIVORA ONE application data may include:

- Products
- Orders
- Customers
- Tasks
- Homeopathic records
- Income
- Expenses
- Purchases
- Sales
- Baki / receivables
- Cart

Use the supplied data only when relevant to the user's question.

Application:
${JSON.stringify(appInfo)}

Current NIVORA ONE data:
${JSON.stringify(safeContext)}

Recent conversation:
${JSON.stringify(safeHistory)}
`;

        // ----------------------------------------------------
        // GEMINI REQUEST
        // ----------------------------------------------------

        const endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/" +
            encodeURIComponent(model) +
            ":generateContent?key=" +
            encodeURIComponent(apiKey);

        const geminiBody = {

            systemInstruction: {
                parts: [
                    {
                        text: systemInstruction
                    }
                ]
            },

            contents: [
                {
                    role: "user",
                    parts: [
                        {
                            text: prompt
                        }
                    ]
                }
            ],

            generationConfig: {
                temperature: 0.4,
                maxOutputTokens: 4096
            }
        };

        // ----------------------------------------------------
        // CALL GEMINI
        // ----------------------------------------------------

        const response = await fetch(endpoint, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(geminiBody)
        });

        const data = await response.json();

        // ----------------------------------------------------
        // GEMINI ERROR
        // ----------------------------------------------------

        if (!response.ok) {

            console.error(
                "Gemini API Error:",
                JSON.stringify(data, null, 2)
            );

            const message =
                data?.error?.message ||
                "Gemini AI request failed.";

            return res.status(response.status).json({
                error: message
            });
        }

        // ----------------------------------------------------
        // EXTRACT AI RESPONSE
        // ----------------------------------------------------

        const reply =
            data?.candidates?.[0]?.content?.parts
                ?.map(part => part.text || "")
                .join("")
                .trim();

        // ----------------------------------------------------
        // EMPTY RESPONSE
        // ----------------------------------------------------

        if (!reply) {

            return res.status(502).json({
                error:
                    "AI server থেকে কোনো উত্তর পাওয়া যায়নি।"
            });

        }

        // ----------------------------------------------------
        // SUCCESS
        // ----------------------------------------------------

        return res.json({
            success: true,
            reply: reply,
            model: model
        });

    } catch (error) {

        console.error(
            "NIVORA AI SERVER ERROR:",
            error
        );

        return res.status(500).json({
            error:
                error?.message ||
                "NIVORA AI server-এ সমস্যা হয়েছে।"
        });
    }
});

// ------------------------------------------------------------
// SPA FALLBACK
// ------------------------------------------------------------

app.get("*", (req, res) => {

    res.sendFile(
        path.join(__dirname, "index.html")
    );

});

// ------------------------------------------------------------
// START SERVER
// ------------------------------------------------------------

app.listen(PORT, () => {

    console.log(
        `NIVORA ONE server running on port ${PORT}`
    );

});